<?php 
defined('C5_EXECUTE') or die(_("Access Denied."));

Loader::packageElement('fileset_select_options','simple_image_gallery');

exit;
