<?php	
defined('C5_EXECUTE') or die("Access Denied.");
$APP_VERSION = '5.5.2.1';