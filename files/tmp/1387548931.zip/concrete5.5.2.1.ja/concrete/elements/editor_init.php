<?php	 defined('C5_EXECUTE') or die("Access Denied."); ?>
<?php	 // empty for legacy purposes ?>