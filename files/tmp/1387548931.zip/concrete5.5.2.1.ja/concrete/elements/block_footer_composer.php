<?php	 defined('C5_EXECUTE') or die("Access Denied."); ?>

<?php	 Loader::element('block_footer', array('b' => $b))?>

</div>
</div>