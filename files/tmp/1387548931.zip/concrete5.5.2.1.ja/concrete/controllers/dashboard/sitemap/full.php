<?php	
defined('C5_EXECUTE') or die("Access Denied.");
Loader::controller('/dashboard/base');
class DashboardSitemapFullController extends DashboardBaseController {

	
}