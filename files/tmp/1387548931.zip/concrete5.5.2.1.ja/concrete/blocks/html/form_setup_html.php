<?php	 defined('C5_EXECUTE') or die("Access Denied."); ?>  

<textarea id="ccm-HtmlContent" name="content" style="width: 98%; height: 440px"><?php	echo htmlentities($controllerObj->content, ENT_COMPAT, APP_CHARSET) ?></textarea>
