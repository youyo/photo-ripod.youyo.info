<?php    
defined('C5_EXECUTE') or die(_("Access Denied."));
$controllerObj=$controller;

/* $html = Loader::helper('html');
$this->addheaderItem($html->javascript('jquery.colorpicker.js'));	
$this->addHeaderItem($html->css('ccm.colorpicker.css')); */

?>
<?php     include($this->getBlockPath().'/form_setup_html.php'); ?> 