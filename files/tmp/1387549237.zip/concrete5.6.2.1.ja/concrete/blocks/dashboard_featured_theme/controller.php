<?php	
	defined('C5_EXECUTE') or die("Access Denied.");
	
	class DashboardFeaturedThemeBlockController extends Concrete5_Controller_Block_DashboardFeaturedTheme {

	}