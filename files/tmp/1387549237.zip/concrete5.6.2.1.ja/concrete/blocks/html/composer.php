<?php	
defined('C5_EXECUTE') or die("Access Denied.");
$form = Loader::helper('form');
print $form->textarea($this->field('content'), $content, array(

));

