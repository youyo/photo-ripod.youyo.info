<?php	
	defined('C5_EXECUTE') or die("Access Denied.");
	class ExternalFormBlockController extends Concrete5_Controller_Block_ExternalForm {}