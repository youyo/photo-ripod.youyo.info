<?php

defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemBasicsTimezoneController extends Concrete5_Controller_Dashboard_System_Basics_Timezone {

}