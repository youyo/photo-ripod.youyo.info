<?php	

defined('C5_EXECUTE') or die("Access Denied.");
class DashboardExtendUpdateController extends Concrete5_Controller_Dashboard_Extend_Update {}