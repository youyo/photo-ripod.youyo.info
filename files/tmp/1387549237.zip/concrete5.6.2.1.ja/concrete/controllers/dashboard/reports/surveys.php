<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardReportsSurveysController extends Concrete5_Controller_Dashboard_Reports_Surveys {
	

}

class SurveyList extends Concrete5_Controller_Block_SurveyList {

}