<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardPageController extends Concrete5_Controller_Dashboard_Page {

	
}