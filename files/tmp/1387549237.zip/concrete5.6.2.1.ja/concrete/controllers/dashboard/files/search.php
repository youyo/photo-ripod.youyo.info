<?php	
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardFilesSearchController extends Concrete5_Controller_Dashboard_Files_Search {


}